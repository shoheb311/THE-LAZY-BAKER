alert('Welcome to our LAZY BAKER webpage')

console.log("The Web page is running....")